<template>
     <!-- 整个页面最外层 -->
     <div class="wrapper">
            <!-- 抬头区 -->
            <header>
                <i class="fa fa-angle-left fa-2x" @click="toTransferOp()"></i>
                <p>选择收款方-马俊双</p>
                <p></p>
            </header>

            <!-- 已经添加的收款人列表部分 -->
            <ul class="recipientList" v-for="item in recipientList">
                <li @click="selectZhuanru(item)">
                    <div class="recipient">
                        <h3>{{item.accountSub.accountName}}</h3>
                        <p>{{ item.accountSub.personInfo.realname }}</p>
                    </div>
                </li>
            </ul>
            <div id="noResult" v-show="isShow">
                暂无可用的收款人数据
            </div>
            <Footer></Footer>
        </div>
</template>

<script>
//引入组件footer
import Footer from '../components/footer.vue';
import axios from 'axios';
import router from "../router";
import {jwtDecode} from 'jwt-decode'
export default{
    //组件的注册
    components:{
        //Footer:Footer
        //组件
        Footer
    },
    data(){
        return{
            recipientList:[],
            isShow:true
        }
    },
    methods:{
        //前往账户页面
        toTransferOp(){
            router.push("/transferOp");
        },
        //从session中获取令牌信息，再从令牌中获取手机对象，再从手机对象中获取到手机号ID
        getRecipientList(){
            // util.js里面的方法
            let mobile=null;
            let token=sessionStorage.getItem('token');
            if(token){
                let tokenObj=jwtDecode(token);
                console.log(tokenObj);
                mobile=JSON.parse(tokenObj.mobileJson);
            }
            let telId=mobile.id;
            let that=this;
            axios.get('/recipient/findAll?telId='+telId)
            .then(function(response){
                let responseBean=response.data;
                let code=responseBean.code;
                if(code==200){
                    that.recipientList=responseBean.data;
                    that.isShow=false;
                }
            })
            .catch(error=>{
                console.log(error);
            })
        },
        //就是点击之后回显的功能，把收款人信息传递并回显到转账操作页面
        selectZhuanru(item){
            let zhuanru=item.accountSub;
            //把收款人的账户信息存入前端的Session中
            //因为转入的是个对象，要转换成JSON字符串才行
            // console.log(zhuanru);
            sessionStorage.setItem('zhuanru',JSON.stringify(zhuanru));
            //跳转回转账操作页面
            router.push('/transferOp');
        }
    },
    mounted:function(){ 
      this.getRecipientList();//需要触发的函数
    }
}
</script>

<style scoped>
/* 整个页面整体样式 */
/* 整个页面整体样式 */
.wrapper{
    width:100%;
    height:100%;
    background-color: #f5f5f5;
}
/* 标题区样式 */
.wrapper header{
    width:100%;
    height:12vw;
    background-color: #00AA91;
    color: #ffffff;
    display: flex;
    /* 设置文字水平居中 */
    justify-content: space-between;
    /* 垂直居中效果 */
    align-items: center;

    /* 使用固定定位,保证header在最上面，不随着翻动而变化 */
    position: fixed;
    top: 0;
    left: 0;

    /* z-index是层级的意思，保证标题永远都在最上层 */
    z-index: 1000;
    font-size: 4.8vw;

    /* 边框盒子效果 */
    box-sizing: border-box;  
    /* 加内边距，拉开两边文字和header便捷的距离 */
    padding: 0 2vw 0 1vw;
}
.wrapper .recipientList{
    width:100%;
    /* 该ul组件的外边距 */
    margin-top: 12vw;
    /* background-color: #ffffff; */
    /* border:1px solid red; */
}
.wrapper .recipientList li{
    width: 100%;
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 2vw;
    box-sizing: border-box;
    margin-bottom: 3vw;
    color: #666666;
    background-color: #FFFFFF;
}

/* 去除div组件的边框 */
.wrapper .recipientList li .recipient{
    width: 100%;
}
.wrapper .recipientList li .recipient h3{
    font-size: 4.6vw;
    /* 字体颜色的透明度 */
    font-weight: 300;
    padding: 0 0 2vw 0;
}
.wrapper .recipientList li .recipient p{
    font-size: 4.6vw;
    padding: 0 0 2vw 0;
}
</style>