<template>
	<div class="wrapper">
		<header>
			<p>用户登录</p>
		</header>
		<ul class="formbox">
			<li>
				<input type="text" placeholder="请输入手机号" v-model="telephone">
			</li>
			<li>
				<input type="password" placeholder="请输入密码" v-model="password">
			</li>
		</ul>
		<div class="btn">
			<button type="button" v-on:click="login">登录</button>
		</div>
		<div class="btn">
			<button type="button" id="reg" v-on:click="register">注册</button>
		</div>
	</div>
</template>
<script setup>
	import {
		inject,
		reactive,
		toRefs
	} from 'vue';
	import {
		useRouter
	} from 'vue-router';
	import qs from 'qs';
	import {
		dealError,
		saveSession
	} from '@/util';
	const router = useRouter();
	const register = () => {
		router.push('/register');
	}
	const axios = inject('axios');
	const data = reactive({
		telephone: '',
		password: ''
	});
	const {
		telephone,
		password
	} = toRefs(data);
	// 编写手机号和密码验证函数
	const check = (str) => {
		if (str == null || str == '') {
			return false;
		}
		return true;
	}
	// 登录函数
	const login = () => {
		if (!check(data.telephone)) {
			alert('手机号必须填写');
			return;
		}
		if (!check(data.password)) {
			alert('密码必须填写');
			return;
		}
		axios.post('mobile/login', qs.stringify({
				telephone: data.telephone,
				password: data.password
			}))
			.then(resp => {
				let responseBean = resp.data;
				let code = responseBean.code;
				
				console.log("login code=" + code);
				if (code == 200) {
					let token = responseBean.data;
					console.log(token);
					// 令牌获得后要保存在前端会话中
					saveSession('token', token);
					// 登录成功后导航到首页
					router.push("/");
				} else {
					router.push({
						path: '/failure',
						query: {
							msg: responseBean.msg
						}
					})
				}
			})
			.catch(error => {
				dealError(error, router);
			});
	}
</script>
<style scoped>
	/* 整个页面整体样式 */
	.wrapper {
		/* 让div高度和body一样高 */
		height: 100%;
		/* 让div的宽度和body一样宽 */
		width: 100%;
		/* 调试样式看边界 */
		/* border: 1px solid black; */
	}

	/* 标题区样式 */
	.wrapper header {
		width: 100%;
		height: 12vw;
		/* border: 1px solid black; */
		display: flex;
		/* 设置文字水平居中 */
		justify-content: center;
		/* 垂直居中效果 */
		align-items: center;
		color: #FFFFFF;
		background-color: #00AA91;
		/* 使用固定定位 */
		position: fixed;
		top: 0;
		left: 0;
		/* 保证标题永远都在最上层 */
		z-index: 1000;
		font-size: 4.8vw;
	}

	.wrapper .formbox {
		width: 100%;
		margin-top: 12vw;
	}

	.wrapper .formbox li {
		/* width: 100%; */
		padding: 4vw 3vw 0 3vw;
	}

	.wrapper .formbox li input {
		width: 100%;
		height: 4vw;
		font-size: 4vw;
		border: none;
		outline: none;
		border-bottom: 1px solid lightgrey;
	}

	.wrapper .btn {
		width: 100%;
		padding: 4vw 3vw 0 3vw;
		box-sizing: border-box;
	}

	.wrapper .btn button {
		width: 100%;
		height: 10vw;
		font-size: 3.8vw;
		font-weight: 700;
		background-color: #00AA91;
		color: #FFFFFF;
		border: none;
		outline: none;
		border-radius: 4px;
	}

	.wrapper .btn #reg {
		color: #00AA91;
		background-color: #FFFFFF;
		border: 4px solid #00AA91;
	}
</style>
