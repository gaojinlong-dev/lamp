<template>
	<div class="wrapper">
		<!-- 标题区 -->
		<header>
			<p>新增关联账户</p>
		</header>
		<!-- 相关账户列表区域 -->
		<ul class="accountList" v-for="item in unRelatedAccountList">
			<li v-on:click="addRelatedAccount(item.id)">
				<div class="account">
					<h3>{{item.accountName}}</h3>
					<p>人民币可用余额：<i class="fa fa-jpy"></i>{{item.balance}}
					</p>
				</div>
			</li>
		</ul>
		<!-- 无关联账户提示区域 -->
		<div id="noResult" v-show="isShow">
			<input type="button" value="无可关联账户,返回上一页" v-on:click="back">
		</div>
		<Footer></Footer>
	</div>
</template>
<script setup>
	import {
		dealError,
		parseToken
	} from '@/util';
	import {
		inject,
		reactive,
		toRefs
	} from 'vue';
	import {
		useRouter
	} from 'vue-router';
	import Footer from '../components/footer.vue'
	import qs from 'qs';
	const axios = inject('axios');
	const router = useRouter();
	const data = reactive({
		unRelatedAccountList: [],
		isShow: true
	});
	const {
		unRelatedAccountList,
		isShow
	} = toRefs(data);
	// 查询未关联账户的函数
	const findUnRelatedAccountByTel = () => {
		let mobile = parseToken();
		let telephone = mobile.telephone;
		let url = 'account/findUnRelatedAccountByTel?telephone=' + telephone;
		axios.get(url)
			.then(resp => {
				let responseBean = resp.data;
				let code = responseBean.code;
				if (code == 200) {
					data.unRelatedAccountList = responseBean.data;
					data.isShow = false;
				}
			})
			.catch(error => {
				dealError(error, router);
			});
	}
	// 利用Vue生命周期在页面载入时开始运行初始化函数
	const init = () => {
		findUnRelatedAccountByTel();
	}
	init();
	const addRelatedAccount = (accountId) => {
		console.log("accountId=" + accountId);
		let mobile = parseToken();
		let telId = mobile.id;
		let url = 'mobileaccount/addRelatedAccount';
		axios.post(url, qs.stringify({
				telId: telId,
				accountId: accountId
			}))
			.then(resp => {
				let responseBean = resp.data;
				let code = responseBean.code;
				if (code == 200) {
					router.push('/accountList');
				}
			})
			.catch(error => {
				dealError(error, router);
			})
	}
	const back = () => {
		router.push("/accountList");
	}
</script>
<style scoped>
	/* 整个页面整体样式 */
	.wrapper {
		/* 让div高度和body一样高 */
		height: 100%;
		/* 让div的宽度和body一样宽 */
		width: 100%;
		/* 调试样式看边界 */
		/* border: 1px solid black; */
		/* 整体背景颜色 */
		background-color: #F5F5F5;
	}

	/* 标题区样式 */
	.wrapper header {
		width: 100%;
		height: 12vw;
		/* border: 1px solid black; */
		display: flex;
		/* 文字水平居中 */
		justify-content: center;
		/* 垂直居中效果 */
		align-items: center;
		color: #FFFFFF;
		background-color: #00AA91;
		/* 使用固定定位 */
		position: fixed;
		top: 0;
		left: 0;
		/* 保证标题永远都在最上层 */
		z-index: 1000;
		font-size: 4.8vw;
	}

	.wrapper .accountList {
		width: 100%;
		margin-top: 12vw;
	}

	.wrapper .accountList li {
		width: 100%;
		border: 1px solid #DADADA;
		margin-bottom: 2vw;
		background-color: #FFFFFF;
	}

	.wrapper .accountList li .account {
		width: 100%;
		
	}

	.wrapper .accountList li .account h3 {
		font-size: 4.6vw;
		font-weight: 300;
		color: #666;
		padding: 2vw;
	}

	.wrapper .accountList li .account p {
		font-size: 4vw;
		color: #666;
		padding: 0 0 2vw 2vw;
	}

	.wrapper #noResult {
		margin-top: 15vw;
	}

	.wrapper #noResult input {
		width: 100%;
		height: 10vw;
		font-size: 3.8vw;
		font-weight: 700;
		color: #FFFFFF;
		background-color: #00AA91;
		border-radius: 4px;
		/* 去掉按钮的外围边框线 */
		border: none;
		/* 去掉按钮的外围轮廓线 */
		outline: none;
	}
</style> 