<template>
	<div class="wrapper">
		<!-- 标题区 -->
		<header>
			<i class="fa fa-angle-left fa-2x"></i>
			<p>账户列表</p>
			<p v-on:click="addRelatedAccount">新增</p>
		</header>
		<!-- 账户列表部分 -->
		<ul class="accountList" v-for="item in relatedAccountList">
			<li>
				<div class="account">
					<h3>{{item.accountName}}</h3>
					<p>人民币可用余额：<i class="fa fa-jpy"></i>{{item.balance}}
					</p>
					<div class="operate">
						<span class="obtn" v-on:click="transRecord(item.id)">
							<i class="fa fa-search"></i>交易记录
						</span>
						<span class="obtn" v-on:click="transferManage(item.id)">
							<i class="fa fa-exchange"></i>对外转帐
						</span>
						<span>
							<i class="fa fa-database"></i>快e宝
						</span>
					</div>
				</div>
			</li>
		</ul>
		<div id="noResult" v-show="isShow">
			尚未添加可以关联的账户
		</div>
		<Footer></Footer>
	</div>
</template>
<script setup>
	import {
		dealError,
		parseToken,
		saveSession
	} from '@/util';
	import {
		inject,
		reactive,
		toRefs
	} from 'vue';
	import {
		useRouter
	} from 'vue-router';
	import Footer from '../components/footer.vue'
	const axios = inject('axios');
	const router = useRouter();
	const data = reactive({
		// 已经关联过的账户列表
		relatedAccountList: [],
		// 控制id为noResult的div显示
		isShow: true
	});
	const {
		relatedAccountList,
		isShow
	} = toRefs(data);
	// 载入已经关联过的账户列表函数
	const findRelatedAccount = () => {
		let mobile = parseToken();
		let telephone = mobile.telephone;
		console.log("telephone:" + telephone);
		let url = '/account/findRelatedAccountByTel?telephone=' + telephone;
		axios.get(url)
			.then(resp => {
				let responseBean = resp.data;
				let code = responseBean.code;
				if (code == 200) {
					data.relatedAccountList = responseBean.data;
					data.isShow = false;
				}
			})
			.catch(error => {
				dealError(error, router);
			});
	}
	// 定义一个页面初始化函数
	const init = () => {
		findRelatedAccount();
	}
	init();
	// 跳转到新增关联账户页面的函数
	const addRelatedAccount = () => {
		router.push('/accountListForSelect');
	}
	// 跳转到转账管理页面
	const transferManage = (accountId) => {
		// 把账户ID存入前端session
		saveSession('accountId', accountId);
		router.push('/transferManage');
	}
	// 跳转到查询交易记录页面
	const transRecord = (accountId) => {
		// 把账户ID存入前端session
		saveSession('accountId', accountId);
		router.push('/transrecord');
	}
</script>
<style scoped>
	/* 整个页面整体样式 */
	.wrapper {
		/* 让div高度和body一样高 */
		height: 100%;
		/* 让div的宽度和body一样宽 */
		width: 100%;
		/* 调试样式看边界 */
		/* border: 1px solid black; */
		/* 整体背景颜色 */
		background-color: #F5F5F5;
	}

	/* 标题区样式 */
	.wrapper header {
		width: 100%;
		height: 12vw;
		/* border: 1px solid black; */
		display: flex;
		/* 平均分配字体标签和两个p标签之间的距离 */
		justify-content: space-between;
		/* 垂直居中效果 */
		align-items: center;
		/* 边框盒子效果 */
		box-sizing: border-box;
		/* 加内边距，拉开两边文字和header边界的距离 */
		padding: 0 2vw 0 1vw;
		color: #FFFFFF;
		background-color: #00AA91;
		/* 使用固定定位 */
		position: fixed;
		top: 0;
		left: 0;
		/* 保证标题永远都在最上层 */
		z-index: 1000;
		font-size: 4.8vw;
	}

	.wrapper .accountList {
		width: 100%;
		margin-top: 12vw;
	}

	.wrapper .accountList li {
		width: 100%;
		border: 1px solid #DADADA;
		margin-bottom: 2vw;
		background-color: #FFFFFF;
	}

	.wrapper .accountList li .account {
		width: 100%;
	}

	.wrapper .accountList li .account h3 {
		font-size: 4.6vw;
		font-weight: 300;
		color: #666;
		padding: 2vw;
	}

	.wrapper .accountList li .account p {
		font-size: 4vw;
		color: #666;
		padding: 0 0 2vw 2vw;
	}

	.wrapper .accountList li .account .operate {
		border-top: 1px solid #DADADA;
		padding: 2vw 0;
		width: 100%;
		text-align: center;
	}

	.wrapper .accountList li .account .operate span {
		padding: 0 6vw;
	}

	.wrapper .accountList li .account .operate .obtn {
		border-right: 1px solid #DADADA;
	}

	.wrapper #noResult {
		margin-top: 12vw;
		text-align: center;
	}
</style>
