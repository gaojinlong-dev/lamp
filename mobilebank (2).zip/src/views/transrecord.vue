<template>
	<div class="wrapper">
		<header>
			<i class="fa fa-angle-left fa-2x" v-on:click="back"></i>
			<p>交易记录</p>
			<!--将来header使用弹性布局，令交易记录四个字居中能用到 -->
			<p></p>
		</header>
		<div class="total">
			<!-- 余额区域 -->
			<div class="balance">
				当前账户余额：<i class="fa fa-jpy"></i>{{balance}}
			</div>
			<!-- 收支区域 -->
			<div class="IncomeAndExpense">
				<!-- 总收入 -->
				<div class="income">
					总收入：
					<i class="fa fa-plus"></i>
					<i class="fa fa-jpy"></i>{{totalIncome}}
				</div>
				<!-- 总支出 -->
				<div class="expense">
					总支出：
					<i class="fa fa-minus"></i>
					<i class="fa fa-jpy"></i>{{totalExpense}}
				</div>
			</div>
		</div>
		<ul class="transrecordList">
			<li v-for="t in transRecordList">
				<div class="account" v-if="t.transtypeId==2">
					<p>交易类型：转账</p>
					<!-- 如果当前账户在转账交易中是支出方（贷方） -->
					<!-- 则交易人信息应该是收款方人名信息（借方） -->
					<p v-if="t.accountId!=accountId">
						交易人:{{t.accountSubA.personInfo.realname}}
					</p>
					<!-- 与上述相反的情况 -->
					<p v-else>
						交易人:{{t.accountSubB.personInfo.realname}}
					</p>
					<!-- 如果当前账户在转账交易中是支出方（贷方） -->
					<!-- 则交易人信息应该是收款方账户信息（借方） -->
					<p v-if="t.accountId!=accountId">
						账号:{{t.accountSubA.accountName}}
					</p>
					<!-- 与上述相反的情况 -->
					<p v-else>
						账号:{{t.accountSubB.accountName}}
					</p>
					<p>交易时间：{{t.transDate}}</p>
				</div>
				<div class="account" v-else-if="t.transtypeId==0">
					<p>交易类型：存款</p>
					<p>交易时间：{{t.transDate}}</p>
				</div>
				<div class="account" v-else>
					<p>交易类型：取款</p>
					<p>交易时间：{{t.transDate}}</p>
				</div>
				<div class="money">
					<!-- 当前账号是转账的收入方（借方） -->
					<i v-if="t.transtypeId==2&&t.accountId==accountId" class="fafa-plus"></i>
					<!-- 当前账号是转账的支出方（贷方） -->
					<i v-else-if="t.transtypeId==2&&t.accountId!=accountId" class="fafa-minus"></i>
					<!-- 当前账号是自行取款 -->
					<i v-else-if="t.transtypeId==1" class="fafa-minus"></i>
					<!-- 排除以上三种情况，则只剩下存款了 -->
					<i v-else class="fa fa-plus"></i>
					<i class="fa fa-jpy"></i>{{t.money}}
				</div>
			</li>
		</ul>
		<Footer></Footer>
	</div>
</template>
<script setup>
	import {
		dealError,
		getSession
	} from '@/util';
	import {
		computed,
		inject,
		reactive,
		toRefs
	} from 'vue';
	import {
		useRouter
	} from 'vue-router';
	import Footer from '../components/footer.vue';
	const router = useRouter();
	const axios = inject('axios');
	const data = reactive({
		transRecordList: [],
		balance: 0,
		// 后端没有交易记录的提示
		msg: '',
		// 账户ID
		accountId: getSession('accountId'),
		// 总收入计算属性
		totalIncome: computed(() => {
			let sum = 0;
			for (let t of data.transRecordList) {
				if (t.transtypeId == 0 ||
					(t.transtypeId == 2 && t.accountId == data.accountId)) {
					sum += t.money;
				}
			}
			return sum;
		}),
		// 总支出计算属性
		totalExpense: computed(() => {
			let sum = 0;
			for (let t of data.transRecordList) {
				if (t.transtypeId == 1 ||
					(t.transtypeId == 2 && t.accountId != data.accountId)) {
					sum += t.money;
				}
			}
			return sum;
		})
	});
	const {
		transRecordList,
		balance,
		msg,
		accountId,
		totalIncome,
		totalExpense
	}=toRefs(data);
	// 获取交易记录的函数
	const getTransRecordList=()=>{
		let url = 'transrecord/findTransRecord?accountId=' + getSession('accountId');
		axios.get(url)
			.then(resp => {
				let responseBean = resp.data;
				let code = responseBean.code;
				if (code == 200) {
					data.transRecordList = responseBean.data;
				} else {
					data.msg = responseBean.msg;
				}
			})
			.catch(error => {
				dealError(error, router);
			});
	}
	// 获取账户余额的函数
	const getBalance = () => {
		let url = 'account/searchByAccountId?accountId='+getSession('accountId');
		axios.get(url)
			.then(resp => {
				let responseBean = resp.data;
				let code = responseBean.code;
				if (code == 200) {
					let account = responseBean.data;
					data.balance = account.balance;
				}
			})
			.catch(error => {
				dealError(error, router);
			});
	}
	const init = () => {
		getBalance();
		getTransRecordList();
	}
	init();
	const back = () => {
		router.push('/accountList');
	}
</script>
<style scoped>
	.wrapper {
		/* 让div高度和body一样高 */
		height: 100%;
		/* 让div的宽度和body一样宽 */
		width: 100%;
		/* 调试样式看边界 */
		/* border: 1px solid black; */
	}

	/* 标题区样式 */
	.wrapper header {
		width: 100%;
		height: 12vw;
		/* border: 1px solid black; */
		display: flex;
		/* 字体标签和两个p之间保持相等的距离 */
		justify-content: space-between;
		/* 垂直居中效果 */
		align-items: center;
		/* 内边距 */
		padding: 0 10vw 0 1vw;
		/* 边框盒子模型样式保持div在使用了内边距情况下宽度不变 */
		box-sizing: border-box;
		color: #FFFFFF;
		background-color: #00AA91;
		/* 使用固定定位 */
		position: fixed;
		top: 0;
		left: 0;
		/* 保证标题永远都在最上层 */
		z-index: 1000;
		font-size: 4.8vw;
	}

	/* 账户余额区域样式 */
	.wrapper .total {
		width: 100%;
		background-color: #00AA91;
		color: #FFFFFF;
		position: fixed;
		left: 0;
		top: 12vw;
		padding: 0 2vw;
		box-sizing: border-box;
	}

	.wrapper .total .balance {
		width: 100%;
		display: flex;
		justify-content: center;
		align-items: center;
	}

	.wrapper .total .IncomeAndExpense {
		width: 100%;
		display: flex;
		justify-content: space-between;
		padding: 2vw 0;
	}

	/* 交易记录列表样式 */
	.wrapper .transrecordList {
		margin-top: 30vw;
		width: 100%;
		padding: 0 2vw;
		box-sizing: border-box;
	}

	.wrapper .transrecordList li {
		width: 100%;
		display: flex;
		justify-content: space-between;
		align-items: center;
		padding: 2vw;
		box-sizing: border-box;
		color: #00AA91;
		border-bottom: 2px solid #D3D3D3;
	}

	.wrapper .transrecordList li .account p {
		font-size: 4.6vw;
	}
</style>
