<template>
	<div class="wrapper">
		<header>
			<i class="fa fa-angle-left fa-2x"></i>
			<p>密码确认</p>
			<p></p>
		</header>
		<ul class="formbox">
			<li>
				<input type="password" placeholder="请输入密码" v-model="firstPassword">
			</li>
			<li>
				<input type="password" placeholder="请再次输入密码" v-model="secondPassword">
			</li>
		</ul>
		<div class="btn">
			<button type="button" v-on:click="reg">注册</button>
		</div>
	</div>
</template>
<script setup>
	import {
		dealError
	} from '@/util';
	import qs from 'qs';
	import {
		reactive,
		toRefs,
		inject
	} from 'vue';
	import {
		useRoute,
		useRouter
	} from 'vue-router';
	const axios = inject('axios');
	const router = useRouter();
	const route = useRoute();
	const data = reactive({
		firstPassword: '',
		secondPassword: '',
		telephone: route.query.telephone
	})
	const {
		firstPassword,
		secondPassword,
		telephone
	} = toRefs(data);
	// 检查密码格式的函数
	const checkPassword = () => {
		if (data.firstPassword == null || data.firstPassword == '') {
			alert('密码不能为空');
			return false;
		}
		if (data.secondPassword == null || data.secondPassword == '') {
			alert('密码不能为空');
			return false;
		}
		if (data.firstPassword != data.secondPassword) {
			alert('两次输入的密码必须相等');
			return false;
		}
		return true;
	}
	// 向后端提交手机号和密码的函数
	const reg = () => {
		if (!checkPassword()) {
			return;
		}
		axios.post('mobile/regMobile', qs.stringify({
				telephone: data.telephone,
				password: data.firstPassword
			}))
			.then(resp => {
				let responseBean = resp.data;
				let code = responseBean.code;
				if (code == 200) {
					router.push({
						path: '/success',
						query: {
							telephone: data.telephone
						}
					})
				}
			})
			.catch(error => {
				// // 获取后端异常状态下的响应对象
				// let response=error.response;
				// // response不为null的情况下
				// if(response){
				// let responseBean=response.data;
				// // 以友好形式向前端使用者显示有异常信息
				// // alert(responseBean.msg);
				// router.push({
				// path:'/failure',
				// query:{
				// msg:responseBean.msg
				// }
				// })
				// }
				dealError(error, router);
			});
	}
</script>
<style scoped>
	/* 整个页面整体样式 */
	.wrapper {
		/* 让div高度和body一样高 */
		height: 100%;
		/* 让div的宽度和body一样宽 */
		width: 100%;
		/* 调试样式看边界 */
		/* border: 1px solid black; */
	}

	/* 标题区样式 */
	.wrapper header {
		width: 100%;
		height: 12vw;
		/* border: 1px solid black; */
		display: flex;
		/* 字体标签和两个p之间保持相等的距离 */
		justify-content: space-between;
		/* 垂直居中效果 */
		align-items: center;
		/* 内边距 */
		padding: 0 5vw 0 1vw;
		/* 边框盒子模型样式保持div在使用了内边距情况下宽度不变 */
		box-sizing: border-box;
		color: #FFFFFF;
		background-color: #00AA91;
		/* 使用固定定位 */
		position: fixed;
		top: 0;
		left: 0;
		/* 保证标题永远都在最上层 */
		z-index: 1000;
		font-size: 4.8vw;
	}

	.wrapper .formbox {
		width: 100%;
		margin-top: 12vw;
	}

	.wrapper .formbox li {
		/* width: 100%; */
		padding: 4vw 3vw 0 3vw;
	}

	.wrapper .formbox li input {
		width: 100%;
		height: 4vw;
		font-size: 4vw;
		border: none;
		outline: none;
		border-bottom: 1px solid lightgrey;
	}

	.wrapper .btn {
		width: 100%;
		padding: 4vw 3vw 0 3vw;
		box-sizing: border-box;
	}

	.wrapper .btn button {
		width: 100%;
		height: 10vw;
		font-size: 3.8vw;
		font-weight: 700;
		background-color: #00AA91;
		color: #FFFFFF;
		border: none;
		outline: none;
		border-radius: 4px;
	}

	.wrapper .btn #reg {
		color: #00AA91;
		background-color: #FFFFFF;
		border: 4px solid #00AA91;
	}
</style>
