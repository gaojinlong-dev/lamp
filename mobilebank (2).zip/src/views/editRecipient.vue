<template>
	<div class="wrapper">
		<!-- 标题区 -->
		<header>
			<i class="fa fa-angle-left fa-2x"></i>
			<p>修改收款方</p>
			<!--将来header使用弹性布局，令添加收款方等几个字居中能用到 -->
			<p></p>
		</header>
		<!-- 收款人信息填写 -->
		<ul class="accountList">
			<li>
				<input type="text" placeholder="收款方姓名" v-model="realname" />
			</li>
			<li>
				<input type="text" placeholder="收款方账号" v-model="accountName" />
			</li>
		</ul>
		<!-- 错误提示 -->
		<div class="tip">
			<span>{{msg}}</span>
		</div>
		<!-- 提交按钮 -->
		<div class="editbtn">
			<button type="button" v-on:click="update">修改</button>
		</div>
		<div class="editbtn">
			<button type="button" v-on:click="remove">删除</button>
		</div>
		<Footer></Footer>
	</div>
</template>
<script setup>
	import {useRouter} from 'vue-router';
	import {dealError,parseToken,getSession} from '@/util';
	import {inject,reactive,toRefs} from 'vue';
	import Footer from '../components/footer.vue';
	import qs from 'qs';
	const router = useRouter();
	const data = reactive({
		realname: JSON.parse(getSession('recipient')).accountSub.personInfo.realname,
		accountName: JSON.parse(getSession('recipient')).accountSub.accountName,
		msg: ''
	})
	const {
		realname,
		accountName,
		msg
	} = toRefs(data);
	const axios = inject('axios');
	const update = () => {
		let recipient = JSON.parse(getSession('recipient'));
		let id = recipient.id;
		let url = 'recipient/updateRecipient';
		axios.post(url, {
				realname: data.realname,
				accountName: data.accountName,
				id: id
			})
			.then(resp => {
				let responseBean = resp.data;
				let code = responseBean.code;
				if (code == 200) {
					router.push("/recipientList");
				} else {
					let msg = responseBean.msg;
					data.msg = msg;
				}
			})
			.catch(error => {
				dealError(error, router);
			});
	}
	const remove = () => {
		let recipient = JSON.parse(getSession('recipient'));
		let id = recipient.id;
		let url = 'recipient/removeRecipient';
		axios.post(url, qs.stringify({
				recipientId: id
			}))
			.then(resp => {
				let responseBean = resp.data;
				let code = responseBean.code;
				if (code == 200) {
					router.push("/recipientList");
				}
			})
			.catch(error => {
				dealError(error, router);
			});
	}
</script>
<style scoped>
	/* 整体页面布局样式 */
	.wrapper {
		/* 让div高度和body一样高 */
		height: 100%;
		/* 让div的宽度和body一样宽 */
		width: 100%;
		/* 调试样式看边界 */
		/* border: 1px solid black; */
		background-color: #F5F5F5;
	}

	/* 标题区样式 */
	.wrapper header {
		width: 100%;
		height: 12vw;
		/* border: 1px solid black; */
		display: flex;
		/* 字体标签和两个p之间保持相等的距离 */
		justify-content: space-between;
		/* 垂直居中效果 */
		align-items: center;
		/* 内边距 */
		padding: 0 10vw 0 1vw;
		/* 边框盒子模型样式保持div在使用了内边距情况下宽度不变 */
		box-sizing: border-box;
		color: #FFFFFF;
		background-color: #00AA91;
		/* 使用固定定位 */
		position: fixed;
		top: 0;
		left: 0;
		/* 保证标题永远都在最上层 */
		z-index: 1000;
		font-size: 4.8vw;
	}

	.wrapper .accountList {
		width: 100%;
		margin-top: 12vw;
	}

	.wrapper .accountList li {
		width: 100%;
		border-bottom: 2px solid #DDD;
		display: flex;
	}

	.wrapper .accountList li input {
		width: 100%;
		height: 8vw;
		font-size: 4vw;
		padding: 2vw;
		border: none;
		outline: none;
	}

	.wrapper .editbtn {
		width: 100%;
		padding: 4vw 3vw 0 3vw;
		box-sizing: border-box;
	}

	.wrapper .editbtn button {
		width: 100%;
		height: 10vw;
		font-size: 3.8vw;
		font-weight: 700;
		background-color: #00AA91;
		color: #FFFFFF;
		border: none;
		outline: none;
		border-radius: 4px;
	}

	/* 错误提示区样式 */
	.wrapper .tip {
		text-align: center;
		padding: 2vw;
		font-weight: bolder;
		color: red;
	}
</style>