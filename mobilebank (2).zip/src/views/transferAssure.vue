<template>
	<div class="wrapper">
		<!-- 标题区 -->
		<header>
			<i class="fa fa-angle-left fa-2x"></i>
			<p>转账确认</p>
			<p></p>
		</header>
		<!-- 信息确认区 -->
		<ul class="transfer">
			<li>
				<p>转出账户：{{zhuanchu.accountName}}</p>
			</li>
			<li>
				<p>收款人姓名：{{zhuanru.personInfo.realname}}</p>
			</li>
			<li>
				<p>转账金额：{{money}}</p>
			</li>
			<li>
				<input type="password" placeholder="支付密码" class="password" v-model="password">
				<span style="color: red;">{{msg}}</span>
			</li>
		</ul>
		<!-- 提交按钮 -->
		<div class="button_sub">
			<button type="button" v-on:click="transfer">提交</button>
		</div>
		<Footer></Footer>
	</div>
</template>
<script setup>
	import {dealError,getSession,removeSession} from '@/util';
	import {inject,reactive,toRefs} from 'vue';
	import {useRoute,useRouter} from 'vue-router';
	import Footer from '../components/footer.vue';
	const route = useRoute();
	const axios = inject('axios');
	const router = useRouter();
	const data = reactive({
		// 转入方
		zhuanru: {},
		// 转出方
		zhuanchu: {},
		// 交易金额
		money: route.query.money,
		// 支付密码
		password: '',
		// 支付密码不匹配的错误提示
		msg: ''
	});
	const {
		zhuanru,
		zhuanchu,
		money,
		password,
		msg
	} = toRefs(data);
	const init = () => {
		let zhuanchuStr = getSession('zhuanchu');
		let zhuanchu = JSON.parse(zhuanchuStr);
		console.log(zhuanchu);
		let zhuanruStr = getSession('zhuanru');
		let zhuanru = JSON.parse(zhuanruStr);
		console.log(zhuanru);
		// 给响应式数据中转入、转出方赋值
		data.zhuanru = zhuanru;
		data.zhuanchu = zhuanchu;
	}
	init();
	const transfer = () => {
		let url = 'transfer/trans';
		axios.post(url, {
				zhuanchu: {
					id: getSession('accountId'),
					balance: data.money,
					password: data.password
				},
				zhuanru: {
					id: data.zhuanru.id,
					balance: data.money
				}
			})
			.then(resp => {
				let responseBean = resp.data;
				let code = responseBean.code;
				if (code == 200) {
					removeSession('zhuanru');
					removeSession('zhuanchu');
					router.push('/success');
				} else {
					data.msg = responseBean.msg;
				}
			})
			.catch(error => {
				// let response=error.response;
				// if(response){
				// let responseBean=response.data;
				// let msg=responseBean.msg;
				// router.push({
				// path:'/failure',
				// query:{
				// msg:msg
				// }
				// })
				// }
				dealError(error, router);
			});
	}
</script>
<style scoped>
	/* 整体页面布局样式 */
	.wrapper {
		/* 让div高度和body一样高 */
		height: 100%;
		/* 让div的宽度和body一样宽 */
		width: 100%;
		/* 调试样式看边界 */
		/* border: 1px solid black; */
		background-color: #F5F5F5;
	}

	/* 标题区样式 */
	.wrapper header {
		width: 100%;
		height: 12vw;
		/* border: 1px solid black; */
		display: flex;
		/* 字体标签和两个p之间保持相等的距离 */
		justify-content: space-between;
		/* 垂直居中效果 */
		align-items: center;
		/* 内边距 */
		padding: 0 5vw 0 1vw;
		/* 边框盒子模型样式保持div在使用了内边距情况下宽度不变 */
		box-sizing: border-box;
		color: #FFFFFF;
		background-color: #00AA91;
		/* 使用固定定位 */
		position: fixed;
		top: 0;
		left: 0;
		/* 保证标题永远都在最上层 */
		z-index: 1000;
		font-size: 4.8vw;
	}

	.wrapper .transfer {
		width: 100%;
		margin-top: 12vw;
	}

	.wrapper .transfer li {
		margin-bottom: 2vw;
		background-color: #FFFFFF;
		padding: 2vw;
	}

	.wrapper .transfer li p {
		font-size: 4vw;
	}

	.wrapper .transfer li .password {
		border: none;
		outline: none;
		font-size: 4vw;
		border-bottom: 1px solid #DEDEDE;
	}

	.wrapper .button_sub {
		width: 100%;
		padding: 4vw 3vw 0 3vw;
		box-sizing: border-box;
	}

	.wrapper .button_sub button {
		width: 100%;
		height: 10vw;
		font-size: 3.8vw;
		font-weight: 700;

		background-color: #00AA91;
		color: #FFFFFF;
		border: none;
		outline: none;
		border-radius: 4px;
	}
</style>