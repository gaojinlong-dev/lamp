<template>
	<div class="wrapper">
		<!-- 标题区 -->
		<header>
			<i class="fa fa-angle-left fa-2x" v-on:click="back"></i>
			<p>收款方列表</p>
			<p v-on:click="addRecipient">新增</p>
		</header>
		<!-- 已经添加的收款人列表 -->
		<ul class="recipientList" v-for="item in recipientList">
			<li v-on:click="editRecipient(item)">
				<div class="recipient">
					<h3>{{item.accountSub.accountName}}</h3>
					<p>{{item.accountSub.personInfo.realname}}</p>
				</div>
				<i class="fa fa-angle-right fa-2x"></i>
			</li>
		</ul>
		<div id="noResult" v-show="isShow">暂无可用的收款人数据</div>
		<Footer></Footer>
	</div>
</template>
<script setup>
	import {
		dealError,
		parseToken,
		saveSession
	} from '@/util';
	import {
		inject,
		reactive,
		toRefs
	} from 'vue';
	import {
		useRouter
	} from 'vue-router';
	import Footer from '../components/footer.vue'
	const axios = inject('axios');
	const router = useRouter();
	const data = reactive({
		recipientList: [],
		isShow: true
	})
	const {
		recipientList,
		isShow
	} = toRefs(data);
	const getRecipientList = () => {
		let mobile = parseToken();
		let telId = mobile.id;
		axios.get('/recipient/findAll?telId=' + telId)
			.then(resp => {
				let responseBean = resp.data;
				let code = responseBean.code;
				if (code == 200) {
					data.recipientList = responseBean.data;
					data.isShow = false;
				}
			})
			.catch(error => {
				dealError(error, router);
			});
	}
	const init = () => {
		getRecipientList();
	}
	init();
	// 前往添加收款人的页面
	const addRecipient = () => {
		router.push('/addRecipient');
	}
	// 前往收款人修改界面
	const editRecipient = (recipient) => {
		let str = JSON.stringify(recipient);
		saveSession('recipient', str);
		router.push('/editRecipient');
	}
	// 返回交易管理界面
	const back = () => {
		router.push('/transferManage');
	}
</script>
<style scoped>
	/* 整体页面布局样式 */
	.wrapper {
		/* 让div高度和body一样高 */
		height: 100%;
		/* 让div的宽度和body一样宽 */
		width: 100%;
		/* 调试样式看边界 */
		/* border: 1px solid black; */
		background-color: #F5F5F5;
	}

	/* 标题区样式 */
	.wrapper header {
		width: 100%;
		height: 12vw;
		/* border: 1px solid black; */
		display: flex;
		/* 字体标签和两个p之间保持相等的距离 */
		justify-content: space-between;
		/* 垂直居中效果 */
		align-items: center;
		/* 内边距 */
		padding: 0 2vw 0 1vw;
		/* 边框盒子模型样式保持div在使用了内边距情况下宽度不变 */
		box-sizing: border-box;
		color: #FFFFFF;
		background-color: #00AA91;
		/* 使用固定定位 */
		position: fixed;
		top: 0;
		left: 0;
		/* 保证标题永远都在最上层 */
		z-index: 1000;
		font-size: 4.8vw;
	}

	.wrapper .recipientList {
		width: 100%;
		margin-top: 12vw;
	}

	.wrapper .recipientList li {
		width: 100%;
		display: flex;
		justify-content: space-between;
		align-items: center;
		padding: 2vw;
		box-sizing: border-box;
		margin-bottom: 3vw;
		background-color: #FFFFFF;
		color: #666666;
	}

	.wrapper .recipientList li .recipient h3 {
		font-size: 4.6vw;
		padding: 0 0 2vw 0;
		font-weight: 300;
	}

	.wrapper .recipientList li .recipient p {
		font-size: 4.6vw;
		padding: 0 0 2vw 0;
	}

	.wrapper #noResult {
		margin-top: 12vw;
		text-align: center;
	}
</style>