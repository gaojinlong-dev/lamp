<template>
	<div class="wrapper">
		<!-- 标题区 -->
		<header>
			<i class="fa fa-angle-left fa-2x"></i>
			<p>自助注册</p>
			<p></p>
		</header>
		<!-- 表单区域 -->
		<ul class="formbox">
			<li>
				<div class="content">
					<input type="text" placeholder="请输入手机号" v-model="telephone">
				</div>
			</li>
			<li>
				<div class="content">
					<input type="text" placeholder="请输入短信验证码" v-model="code">
					<button type="button" v-on:click="getCode">获取验证码</button>
				</div>
			</li>
		</ul>
		<div class="btn">
			<button type="button" v-on:click="subCode">下一步</button>
		</div>
	</div>
</template>
<script setup>
	import {
		inject,
		reactive,
		toRefs
	} from 'vue';
	import {
		useRouter
	} from 'vue-router';
	import qs from 'qs';
	import {
		dealError
	} from '@/util';
	const data = reactive({
		telephone: '',
		code: ''
	})
	const {
		telephone,
		code
	} = toRefs(data);
	const axios = inject('axios');
	const router = useRouter();
	// 验证手机号填写是否正确
	const checkTel = () => {
	if (data.telephone == null || data.telephone == '') {
		alert('请填写手机号');
		return false;
	}
	if (data.telephone.length < 11) {
		alert('手机号不足11位');
		return false;
	}
	let telExp = /^(13[0-9]|14[01456879]|15[0-35-9]|16[2567]|17[0-8]|18[0-9] | 19[0 - 35 - 9])\ d {8}$ / ;
	if (telExp.test(data.telephone)) {
		alert('手机号不符合移动通讯手机规范');
		return false;
	}
	return true;
	}
	// 获取后端验证码的函数
	const getCode = () => {
		// 申请验证码前需要先进行手机号业务规则检验
		// 如果校验规则不通过，则终止该函数后续代码执行
		if (!checkTel()) {
			return;
		}
		// 如果校验规则通过，再向后端发送请求
		axios.get('mobile/sendCode?telephone=' + data.telephone)
			.then(resp => {
				// 获取后端发送的全局响应数据对象
				let responseBean = resp.data;
				if (responseBean.code == 200) {
					let checkCode = responseBean.data;
					alert('短信验证码为：' + checkCode + '，请在2分钟之内使用');
				} else {
					alert(responseBean.msg);
				}
			})
			.catch(error => {
				dealError(error, router);
			});
	}
	// 检查验证码格式的函数
	const checkCodeFormat = () => {
		if (data.code == null || data.code == '') {
			alert('验证码必须填写')
			return false;
		}
		if (data.code.length < 4) {
			alert('验证码长度不满足4位')
			return false;
		}
		let codeExp = /^\d{4}$/;
		if (!codeExp.test(data.code)) {
			alert('验证码必须满足4位整数,不能含有其他字符');
			return false;
		}
		return true;
	}
	// 向后台提交验证码的函数
	const subCode = () => {
		// 提交验证码前校验手机号
		if (!checkTel()) {
			return;
		}
		// 提交验证码前校验验证码
		if (!checkCodeFormat()) {
			return;
		}
		axios.post('mobile/checkCode', qs.stringify({
				telephone: data.telephone,
				code: data.code
			}))
			.then(resp => {
				let responseBean = resp.data;
				let code = responseBean.code;
				if (code == 200) {
					router.push({
						path: '/password',
						query: {
							telephone: data.telephone
						}
					})
				} else {
					alert(responseBean.msg);
				}
			})
			.catch(error => {
				dealError(error, router);
			});
	}
</script>
<style scoped>
	/* 整个页面整体样式 */
	.wrapper {
		/* 让div高度和body一样高 */
		height: 100%;
		/* 让div的宽度和body一样宽 */
		width: 100%;
		/* 调试样式看边界 */
		/* border: 1px solid black; */
	}

	/* 标题区样式 */
	.wrapper header {
		width: 100%;
		height: 12vw;
		/* border: 1px solid black; */
		display: flex;
		/* 字体标签和两个p之间保持相等的距离 */
		justify-content: space-between;
		/* 垂直居中效果 */
		align-items: center;
		/* 内边距 */
		padding: 0 5vw 0 1vw;
		/* 边框盒子模型样式保持div在使用了内边距情况下宽度不变 */
		box-sizing: border-box;
		color: #FFFFFF;
		background-color: #00AA91;
		/* 使用固定定位 */
		position: fixed;
		top: 0;
		left: 0;
		/* 保证标题永远都在最上层 */
		z-index: 1000;
		font-size: 4.8vw;
	}

	.wrapper .formbox {
		width: 100%;
		margin-top: 12vw;
	}

	.wrapper .formbox li {
		padding: 4vw 3vw 0 3vw;
	}

	.wrapper .formbox li .content input {
		border: none;
		outline: none;
		height: 4vw;
		font-size: 4vw;
	}

	.wrapper .formbox li .content button {
		font-size: 4vw;
		color: #00AA91;
		background-color: #FFFFFF;
		border: 1px solid #00AA91;
	}

	.wrapper .btn {
		width: 100%;
		padding: 4vw 3vw 0 3vw;
		box-sizing: border-box;
	}

	.wrapper .btn button {
		width: 100%;
		height: 10vw;
		font-size: 3.8vw;
		font-weight: 700;
		background-color: #00AA91;
		color: #FFFFFF;
		border: none;
		outline: none;
		border-radius: 4px;
	}
</style>
