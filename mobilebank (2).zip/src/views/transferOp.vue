<template>
	<div class="wrapper">
		<!-- 标题区 -->
		<header>
			<i class="fa fa-angle-left fa-2x"></i>
			<p>转账操作</p>
			<p></p>
		</header>
		<!-- 转账操作信息区 -->
		<ul class="transfer">
			<!-- 转出账户信息 -->
			<li>
				<p>您的转出账户</p>
				<div class="account">
					<p>{{zhuanchu.accountName}}</p>
				</div>
				<p>当前余额：<i class="fa fa-jpy"></i>{{zhuanchu.balance}}</p>
			</li>
			<!-- 转入账户信息 -->
			<li>
				<p>选择收款人</p>
				<div class="account">
					<p>收款人姓名：{{zhuanru.personInfo.realname}}</p>
					<i class="fa fa-angle-right" v-on:click="selectZhuanru"></i>
				</div>
				<p>转入账号：{{zhuanru.accountName}}</p>
			</li>
			<!-- 交易金额区 -->
			<li>
				<p>交易金额</p>
				<div class="balance">
					<p>请选择金额，也可以输入其他金额</p>
					<div class="btn">
						<button type="button" v-on:click="selectMoney(500)">500</button>
						<button type="button" v-on:click="selectMoney(1000)">1000</button>
						<button type="button" v-on:click="selectMoney(1500)">1500</button>
						<button type="button" v-on:click="selectMoney(5000)">5000</button>
					</div>
					<div class="money">
						<input type="number" placeholder="其他金额" v-model="money">
						<span style="color: red;">{{tip}}</span>
					</div>
				</div>
			</li>
		</ul>
		<!-- 下一步按钮操作 -->
		<div class="button_next">
			<button type="button" v-on:click="com">下一步</button>
		</div>
		<Footer></Footer>
	</div>
</template>
<script setup>
	import {dealError,getSession,saveSession} from '@/util';
	import {inject,reactive,toRefs} from 'vue';
	import {useRouter} from 'vue-router';
	import Footer from '../components/footer.vue';
	const router = useRouter();
	const axios = inject('axios');
	const data = reactive({
		zhuanchu: {},
		zhuanru: {
			accountName: '',
			personInfo: {
				realname: ''
			}
		},
		money: 0,
		// 交易金额小于转出账户余额的提示
		tip: ''
	})
	const {
		zhuanchu,
		zhuanru,
		money,
		tip
	} = toRefs(data);
	// 按账户ID查询转出方账户信息的函数
	const searchByAccountId = () => {
		let accountId = getSession('accountId');
		let url = 'account/searchByAccountId?accountId=' + accountId;
		axios.get(url)
			.then(resp => {
				let responseBean = resp.data;
				let code = responseBean.code;
				if (code == 200) {
					data.zhuanchu = responseBean.data;
				}
			})
			.catch(error => {
				dealError(error, router);
			});
	}
	const init = () => {
		searchByAccountId();
		let zhuanruStr = getSession('zhuanru');
		if (zhuanruStr != null) {
			data.zhuanru = JSON.parse(zhuanruStr);
		}
	}
	init();
	const selectZhuanru = () => {
		router.push('/recipientListForSelect');
	}
	// 选择界面交易金额的函数
	const selectMoney = (money) => {
		data.money = money;
	}
	// 转账金额比较确认的函数
	const com = () => {
		if (data.zhuanchu.balance > data.money) {
			saveSession('zhuanchu', JSON.stringify(data.zhuanchu));
			router.push({
				path: '/transferAssure',
				query: {
					money: data.money
				}
			})
		} else {
			data.tip = '余额不足';
		}
	}
</script>
<style scoped>
	/* 整体页面布局样式 */
	.wrapper {
		/* 让div高度和body一样高 */
		height: 100%;
		/* 让div的宽度和body一样宽 */
		width: 100%;
		/* 调试样式看边界 */
		/* border: 1px solid black; */
		background-color: #F5F5F5;
	}

	/* 标题区样式 */
	.wrapper header {
		width: 100%;
		height: 12vw;
		/* border: 1px solid black; */
		display: flex;
		/* 字体标签和两个p之间保持相等的距离 */
		justify-content: space-between;
		/* 垂直居中效果 */
		align-items: center;
		/* 内边距 */
		padding: 0 5vw 0 1vw;
		/* 边框盒子模型样式保持div在使用了内边距情况下宽度不变 */
		box-sizing: border-box;
		color: #FFFFFF;
		background-color: #00AA91;
		/* 使用固定定位 */
		position: fixed;
		top: 0;
		left: 0;
		/* 保证标题永远都在最上层 */
		z-index: 1000;
		font-size: 4.8vw;
	}

	.wrapper .transfer {
		width: 100%;
		margin-top: 12vw;
	}

	.wrapper .transfer li {
		margin-bottom: 2vw;
		background-color: #FFFFFF;
		padding: 2vw;
	}

	.wrapper .transfer li p {
		padding-bottom: 2vw;
	    font-size: 4vw;
	}

	.wrapper .transfer li .account {
		display: flex;
		justify-content: space-between;
		padding-right: 2vw;
	}

	.wrapper .transfer li .balance .btn {
		padding-bottom: 2vw;
	}

	.wrapper .transfer li .balance .btn button {
		background-color: #00AA91;
		color: #FFFFFF;
		width: 12vw;
		text-align: center;
		border: none;
		outline: none;
	}

	.wrapper .transfer li .balance .money {
		padding-bottom: 2vw;
	}

	.wrapper .transfer li .balance .money input {
		border: none;
		outline: none;
		font-size: 4vw;
		border-bottom: 1px solid #DEDEDE;
	}

	.wrapper .button_next {
		width: 100%;
		padding: 4vw 3vw 0 3vw;
		box-sizing: border-box;
	}

	.wrapper .button_next button {
		width: 100%;
		height: 10vw;
		font-size: 3.8vw;
		font-weight: 700;
		background-color: #00AA91;
		color: #FFFFFF;
		border: none;
		outline: none;
		border-radius: 4px;
	}
</style>