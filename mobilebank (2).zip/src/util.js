import {jwtDecode} from 'jwt-decode'
//实现登录会话状态的保存
export function saveSession(key, str) {
	sessionStorage.setItem(key, str);
}
//获得登录会话状态
export function getSession(key) {
	return sessionStorage.getItem(key);
}

//从响应的令牌数据解析用户的手机数据
export function parseToken() {
	let mobile = null;
	//获得会话中的token
	let token = getSession('token');
	if (token) {
		//解析token
		let objToken = jwtDecode(token);
		console.log(objToken);
		//获得token中的手机对象
		mobile = JSON.parse(objToken.mobileJson);
	}

	//返回tonkenJson对象获得手机对象
	return mobile;
}

//退出系统，清空会话
export function removeSession(key) {
	sessionStorage.removeItem(key);
}

//封装全局的异常处理
export function dealError(error, router) {
	//获得后端响应的错误信息
	let responseBean = error.response;
	if (responseBean) {
		let resp = responseBean.data;
		router.push({
			path: '/failure',
			query: {
				msg: resp.msg
			}
		});
	}
}
