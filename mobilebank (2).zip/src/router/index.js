import {createRouter,createWebHashHistory} from 'vue-router'
/* 导入vue组件 */
import index from '../views/index.vue'
import login from '../views/login.vue'
import register from '../views/register.vue'
import password from '../views/password.vue'
import accountList from '../views/accountList.vue'
import accountListForSelect from '../views/accountListForSelect.vue'
import transrecord from '../views/transrecord.vue'
import transferManage from '../views/transferManage.vue'
import recipientList from '../views/recipientList.vue'
import recipientListForSelect from '../views/recipientListForSelect.vue'
import addRecipient from '../views/addRecipient.vue'
import editRecipient from '../views/editRecipient.vue'
import transferOp from '../views/transferOp.vue'
import transferAssure from '../views/transferAssure.vue'
import success from '../views/success.vue'
import failure from '../views/failure.vue'


/* 导入utils组件 */
import {getSession} from '../util.js';
const routes = [{
		path: '/',
		component: index
	}, {
		path: '/login',
		component: login
	}, {
		path: '/register',
		component: register
	}, {
		path: '/password',
		component: password
	}, {
		path: '/accountList',
		component: accountList
	}, {
		path: '/accountListForSelect',
		component: accountListForSelect
	}, {
		path: '/transrecord',
		component: transrecord
	}, {
		path: '/transferManage',
		component: transferManage
	},
	{
		path: '/recipientList',
		component: recipientList
	},
	{
		path: '/recipientListForSelect',
		component: recipientListForSelect
	},
	{
		path: '/addRecipient',
		component: addRecipient
	},
	{
		path: '/editRecipient',
		component: editRecipient
	},
	{
		path: '/transferOp',
		component: transferOp
	},
	{
		path: '/transferAssure',
		component: transferAssure
	},
	{
		path: '/success',
		component: success
	},
	{
		path: '/failure',
		component: failure
	}
]

const router = createRouter({
	history: createWebHashHistory(),
	routes
})

/* 过滤不需要验证token的请求，直接放行 */
router.beforeEach((to, from, next) => {
	// 创建路由守卫规则，该规则用集合表示，集合中路径是不需要登录就能访问的路径
	const nextRoute = ['/', '/login', '/register', '/password', '/success', '/failure'];
	// 如果是未登录状态，则token必然为null
	let token = getSession('token');
	console.log("token=" + token);
	if (nextRoute.indexOf(to.path) == -1) {
		// JS中null可以隐式转换成false
		if (!token) {
			router.push('/login');
		}
	}
	next();
})

export default router