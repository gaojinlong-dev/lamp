<template>
	<ul class="footer">
		<li v-on:click="index">
			<i class="fa fa-home"></i>
			<p>首页</p>
		</li>
		<li>
			<i class="fa fa-compass"></i>
			<p>发现</p>
		</li>
		<li v-on:click="accountManage">
			<i class="fa fa-user-o"></i>
			<p>账户</p>
		</li>
	</ul>
</template>

<script setup>
	/* 导入路由组件 */
	import {
		useRouter
	} from 'vue-router';
	
	const router = new useRouter();

	const index = () => {
		router.push('/');
	}
	const accountManage = () => {
		router.push('/accountList');
	}
</script>

<style scoped>
	/* 底部功能区 */
	.footer {
		width: 100%;
		display: flex;
		justify-content: space-around;
		height: 14vw;
		position: fixed;
		left: 0;
		bottom: 0;
		align-items: center;
		background-color: #fff;
		border-top: solid 1px #DDD;
	}

	.footer li {
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
		color: #999999;
	}

	.footer li p {
		font-size: 2.8vw;
	}

	.footer li i {
		font-size: 5vw;
	}
</style>
