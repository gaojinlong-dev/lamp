<template>
	<router-view />
</template>
<script setup>
	/* 导入异步请求组件 */
	import axios from 'axios';
	import {
		provide
	} from 'vue';
	import {
		useRouter
	} from 'vue-router';
	import {
		getSession
	} from './util';
	const router = useRouter();
	/* 异步请求的路径前缀 */
	axios.defaults.baseURL = 'http://localhost:8888/mobilebank/';
	axios.defaults.withCredentials = true;
	// 添加axios的请求拦截器
	axios.interceptors.request.use(config => {
		// 获取前端存储的令牌信息
		let token = getSession('token');
		// 如果令牌不为null,则在请求的头部报文中附加令牌信息
		if (token) {
			console.log("xxxxxxxxxxxxxxxxxx");
			config.headers.authorization = 'Bearer ' + token;
			//console.log(config.headers.authorization);
		}
		return config;
	}, error => {
		return Promise.reject(error);
	})
	// 添加axios的响应拦截器
	axios.interceptors.response.use(response => {
		let result = response.data;
		if (result === 'invalid token') {
			router.push({
				path: '/failure',
				query: {
					msg: '令牌无效，请重新登录',
					code: 902
				}
			})
		}
		return response;
	}, error => {
		return Promise.reject(error);
	})
	provide('axios', axios);
</script>
<style>
	ul {
		/* 去掉无序列表项目中黑点 */
		list-style: none;
	}

	/* 星号代表所有标签 */
	* {
		margin: 0;
		padding: 0;
		font-family: "微软雅黑";
	}

	a {
		/* 去掉超级链接的下划线 */
		text-decoration: none;
		/* 修改超级链接的文字颜色 */
		color: black;
	}

	body,
	html {
		height: 100%;
		width: 100%;
	}

	#app {
		height: 100%;
		width: 100%;
	}
</style>
