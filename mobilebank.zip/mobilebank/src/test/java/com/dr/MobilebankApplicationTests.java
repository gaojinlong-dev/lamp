package com.dr;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MobilebankApplicationTests {

    @Test
    void contextLoads() {
    }

}
