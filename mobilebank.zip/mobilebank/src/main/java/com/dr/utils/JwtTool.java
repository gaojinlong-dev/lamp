package com.dr.utils;

import com.auth0.jwt.JWT;
import com.auth0.jwt.JWTVerifier;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.interfaces.Claim;
import com.auth0.jwt.interfaces.DecodedJWT;

import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/*实现jwt-token的操作*/
public class JwtTool {
    //加密秘钥
    private static final String SECURT="mayun123";
    //token过期时间单位
    private static int UNIT= Calendar.SECOND;
    //token过期时长
    private static int INTERVAL=300;
    /*加密数据，产生token*/
    public static String createToken(String jsonString){
        //获得token的产生时间
        Date start=new Date();

        //获得token的过期时间
        Calendar now = Calendar.getInstance();
        now.add(UNIT,INTERVAL);
        //通过now对象获得300秒后的日期对象
        Date end = now.getTime();

        //指定令牌加密类型和算法
        Map<String,Object> map=new HashMap<>();
        map.put("typ","JWT");
        map.put("alg","HS256");

        String token = JWT.create()
                .withHeader(map)
                .withClaim("mobileJson", jsonString)
                .withIssuedAt(start)//token的产生时间
                .withExpiresAt(end)//token过期时间
                .sign(Algorithm.HMAC256(SECURT));//加密秘钥
        return token;

    }

    /*对象toeken数据进行解析*/
    public static Map<String, Claim> decoderToken(String token){
        DecodedJWT decodedJWT=null;
        JWTVerifier build = JWT.require(Algorithm.HMAC256(SECURT)).build();
        decodedJWT = build.verify(token);
        Map<String, Claim> claims = decodedJWT.getClaims();
        return claims;
    }

    /*获得令牌解析后的json字符串*/
    public static String parseToken(String token){
        Map<String, Claim> stringClaimMap = decoderToken(token);
        Claim mobilejson = stringClaimMap.get("mobilejson");
        return mobilejson.asString();
    }
}
