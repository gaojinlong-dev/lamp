package com.dr.utils;

import java.util.concurrent.ThreadLocalRandom;

/*工具类产生验证码*/
public class Coder {

    public static String checkCode(){
        int random = ThreadLocalRandom.current().nextInt(1000, 10000);
        String s = String.valueOf(random);
        return s;

    }
}
