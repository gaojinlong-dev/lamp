package com.dr.service;

import com.dr.domain.Recipient;
import com.baomidou.mybatisplus.extension.service.IService;
import com.dr.domain.RecipientSub;
import com.dr.domain.ResponseBean;

import java.util.List;
import java.util.Map;

/**
* @author 您好
* @description 针对表【recipient】的数据库操作Service
* @createDate 2024-06-26 08:58:29
*/
public interface RecipientService extends IService<Recipient> {

    /*根据当前用户电话id获得收款人列表*/
    public ResponseBean<List<RecipientSub>> queryRecipientList(Integer tid);
    /*实现收款人添加*/
    public ResponseBean<Integer> saveRecipient(Map<String,Object> map);
    /*实现收款人修改*/
    public ResponseBean<Integer> updateRecipient(Map<String,Object> map);
    /*实现收款人删除*/
    public ResponseBean<Integer> removeRecipient(Integer recipientId);
}
