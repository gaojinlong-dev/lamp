package com.dr.service;

import com.dr.domain.Mobile;
import com.baomidou.mybatisplus.extension.service.IService;
import com.dr.domain.ResponseBean;

/**
* @author 您好
* @description 针对表【mobile】的数据库操作Service
* @createDate 2024-06-26 08:58:29
*/
//通过继承IService接口获得操作业务数据的方法
public interface MobileService extends IService<Mobile> {

    /*实现用户身份验证*/
    public ResponseBean<String> login(Mobile mobile);
    /*实现手机号唯一性验证*/
    public ResponseBean<String> checkPhone(String telephone);
    /*实现验证码的有效性验证*/
    public ResponseBean<String> checkNumber(String code);
    /*实现用户注册*/
    public ResponseBean<Integer> register(Mobile mobile);

}
