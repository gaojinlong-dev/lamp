package com.dr.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.dr.domain.Account;
import com.dr.domain.ResponseBean;
import com.dr.service.AccountService;
import com.dr.mapper.AccountMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
* @author 您好
* @description 针对表【account】的数据库操作Service实现
* @createDate 2024-06-26 08:58:29
*/
@Service
public class AccountServiceImpl extends ServiceImpl<AccountMapper, Account>
    implements AccountService{

    @Autowired
    private AccountMapper accountMapper;
    @Override
    public ResponseBean<List<Account>> findRelatedAccountByTel(String phone) {
        ResponseBean<List<Account>> result=new ResponseBean<>();
        List<Account> accounts = accountMapper.selectAccountListMapper(phone);
        result.setCode(200);
        result.setData(accounts);
        return result;
    }

    @Override
    public ResponseBean<List<Account>> findUnRelatedAccountByTel(String phone) {
        ResponseBean<List<Account>> result=new ResponseBean<>();
        List<Account> accounts = accountMapper.selectUnAccountListMapper(phone);
        result.setCode(200);
        result.setData(accounts);
        return result;
    }
}




