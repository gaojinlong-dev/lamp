package com.dr.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.dr.domain.Dictype;
import com.dr.service.DictypeService;
import com.dr.mapper.DictypeMapper;
import org.springframework.stereotype.Service;

/**
* @author 您好
* @description 针对表【dictype】的数据库操作Service实现
* @createDate 2024-06-26 08:58:29
*/
@Service
public class DictypeServiceImpl extends ServiceImpl<DictypeMapper, Dictype>
    implements DictypeService{

}




