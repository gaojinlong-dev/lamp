package com.dr.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.dr.domain.Dicitem;
import com.dr.service.DicitemService;
import com.dr.mapper.DicitemMapper;
import org.springframework.stereotype.Service;

/**
* @author 您好
* @description 针对表【dicitem】的数据库操作Service实现
* @createDate 2024-06-26 08:58:29
*/
@Service
public class DicitemServiceImpl extends ServiceImpl<DicitemMapper, Dicitem>
    implements DicitemService{

}




