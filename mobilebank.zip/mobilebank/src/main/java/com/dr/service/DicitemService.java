package com.dr.service;

import com.dr.domain.Dicitem;
import com.baomidou.mybatisplus.extension.service.IService;

/**
* @author 您好
* @description 针对表【dicitem】的数据库操作Service
* @createDate 2024-06-26 08:58:29
*/
public interface DicitemService extends IService<Dicitem> {

}
