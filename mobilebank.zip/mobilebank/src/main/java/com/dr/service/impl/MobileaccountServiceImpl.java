package com.dr.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.dr.domain.Mobileaccount;
import com.dr.domain.ResponseBean;
import com.dr.service.MobileaccountService;
import com.dr.mapper.MobileaccountMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
* @author 您好
* @description 针对表【mobileaccount】的数据库操作Service实现
* @createDate 2024-06-26 08:58:29
*/
@Service
public class MobileaccountServiceImpl extends ServiceImpl<MobileaccountMapper, Mobileaccount>
        implements MobileaccountService {
    @Autowired
    private MobileaccountMapper mobileaccountMapper;
    @Override
    public ResponseBean<Integer> addRelatedAccount(Mobileaccount telId ) {
        ResponseBean<Integer> result=new ResponseBean<>();
        Integer row=mobileaccountMapper.insert(telId);
        result.setCode(200);
        result.setData(row);
        return result;
    }

}




