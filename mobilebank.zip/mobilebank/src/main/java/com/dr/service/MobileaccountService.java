package com.dr.service;

import com.dr.domain.Mobileaccount;
import com.baomidou.mybatisplus.extension.service.IService;
import com.dr.domain.ResponseBean;

/**
* @author 您好
* @description 针对表【mobileaccount】的数据库操作Service
* @createDate 2024-06-26 08:58:29
*/
public interface MobileaccountService extends IService<Mobileaccount> {
    // 添加手机和账户的关联信息
    ResponseBean<Integer> addRelatedAccount(Mobileaccount telId);
}
