package com.dr.service;

import com.dr.domain.Account;
import com.baomidou.mybatisplus.extension.service.IService;
import com.dr.domain.ResponseBean;
import io.netty.util.AbstractReferenceCounted;

import java.util.List;

/**
* @author 您好
* @description 针对表【account】的数据库操作Service
* @createDate 2024-06-26 08:58:29
*/
public interface AccountService extends IService<Account> {

    /*加载用户账户列表*/
    public ResponseBean<List<Account>> findRelatedAccountByTel(String phone);

    /*实现加载该手机号未绑定的用户账号*/
    public ResponseBean<List<Account>> findUnRelatedAccountByTel(String phone);
}
