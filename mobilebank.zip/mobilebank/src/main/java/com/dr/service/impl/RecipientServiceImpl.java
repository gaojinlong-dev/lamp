package com.dr.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.dr.domain.*;
import com.dr.mapper.AccountMapper;
import com.dr.mapper.PersoninfoMapper;
import com.dr.service.RecipientService;
import com.dr.mapper.RecipientMapper;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
* @author 您好
* @description 针对表【recipient】的数据库操作Service实现
* @createDate 2024-06-26 08:58:29
*/
@Service
public class RecipientServiceImpl extends ServiceImpl<RecipientMapper, Recipient>
    implements RecipientService{

    @Autowired
    private RecipientMapper recipientMapper;
    @Autowired
    private AccountMapper accountMapper;
    @Autowired
    private PersoninfoMapper personinfoMapper;
    @Override
    public ResponseBean<List<RecipientSub>> queryRecipientList(Integer tid) {
        ResponseBean<List<RecipientSub>> result=new ResponseBean<>();
        //根据tid获得关联的账号
        QueryWrapper<Recipient> wrapper=new QueryWrapper<>();
        wrapper.eq("telId",tid);
        List<Recipient> recipients
                = recipientMapper.selectList(wrapper);//from recipient where telid=?
        if (recipients==null|| recipients.isEmpty()){
            return result;
        }
        List<Integer> receiveIds=new ArrayList<>();
        for(Recipient r:recipients){
            //获得该手机号关联所有收款人账户id
            Integer otherid = r.getOtherid();
            receiveIds.add(otherid);
        }
        //根据收款人账号id集合，获得收款账号信息
        //select * from account where id in ()
        QueryWrapper<Account> accountQueryWrapper=new QueryWrapper<>();
        accountQueryWrapper.in("id",receiveIds);
        List<Account> accounts = accountMapper.selectList(accountQueryWrapper);
        //封装响应到前的数据模型
        List<RecipientSub> recipientSubList=new ArrayList<RecipientSub>();

        //遍历accounts，将数据封装为RecipientSub对象
        for(Account act:accounts){
            RecipientSub recipientSub=new RecipientSub();
            //根据账号id和电话id查询
            QueryWrapper<Recipient> conds=new QueryWrapper<>();
            conds.eq("otherId",act.getId());
            conds.eq("telId",tid);
            Recipient recipient = recipientMapper.selectOne(conds);
            recipientSub.setId(recipient.getId());

            //给recipientSub对象accountSub属性赋值
            AccountSub accountSub=new AccountSub();
//            accountSub.setAccountname(act.getAccountname());
            BeanUtils.copyProperties(act,accountSub);

            //根据act中的personId查询获得该账号对应收款人信息
            Integer personid = act.getPersonid();
            Personinfo personinfo = personinfoMapper.selectById(personid);
            accountSub.setPersonInfo(personinfo);

            recipientSub.setAccountSub(accountSub);
            recipientSubList.add(recipientSub);
        }
        result.setCode(200);
        result.setData(recipientSubList);

        //通过账号中关联的personid获得收款人
        return result;
    }

    @Override
    public ResponseBean<Integer> saveRecipient(Map<String, Object> map) {
        ResponseBean<Integer> result=new ResponseBean<>();
        String accountName= (String) map.get("accountName");
        String realname= (String) map.get("realname");
        //根据真实姓名和账号查询数据，验证姓名和账号是否匹配
        Account account = recipientMapper.checkAccountRealname(accountName, realname);
        if(account==null){
            result.setCode(801);
            result.setMsg("输入账号和真实姓名错误.....");
            return result;
        }

        //验证是否已经是收款人
        Integer id = account.getId();
        Integer telId = (Integer) map.get("telId");
        QueryWrapper<Recipient> wrapper=new QueryWrapper<>();
        wrapper.eq("otherid",id);
        wrapper.eq("telId",telId);
        Recipient recipient = recipientMapper.selectOne(wrapper);
        if(recipient!=null){
            //该收款联系人已经存在，不能重复添加
            result.setCode(802);
            result.setMsg("收款联系人已经存在，不能重复添加.....");
            return result;
        }

        Recipient entity=new Recipient();
        entity.setOtherid(account.getId());
        entity.setTelid(telId);
        //完成收款联系人添加
        int row = recipientMapper.insert(entity);
        result.setCode(200);
        result.setData(row);
        return result;
    }

    @Override
    public ResponseBean<Integer> updateRecipient(Map<String, Object> map) {

        ResponseBean<Integer> result=new ResponseBean<>();
        String accountName= (String) map.get("accountName");
        String realname= (String) map.get("realname");
        //根据真实姓名和账号查询数据，验证姓名和账号是否匹配
        Account account = recipientMapper.checkAccountRealname(accountName, realname);
        if(account==null){
            result.setCode(801);
            result.setMsg("输入账号和真实姓名错误.....");
            return result;
        }


        //获得需要更新数据的id
        Integer id= (Integer) map.get("id");
        Recipient entity=new Recipient();
        entity.setId(id);
        entity.setOtherid(account.getId());
        int row = recipientMapper.updateById(entity);
        result.setCode(200);
        result.setData(row);
        return result;
    }
    @Override
    public ResponseBean<Integer> removeRecipient(Integer recipientId) {
         ResponseBean<Integer> result=new ResponseBean<>();
         Integer row=recipientMapper.deleteById(recipientId);
         result.setCode(200);
         result.setData(row);
         return result;
   }
}




