package com.dr.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.dr.domain.Mobile;
import com.dr.domain.ResponseBean;
import com.dr.service.MobileService;
import com.dr.mapper.MobileMapper;
import com.dr.utils.Coder;
import com.dr.utils.JwtTool;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

import java.util.concurrent.TimeUnit;

/**
* @author 您好
* @description 针对表【mobile】的数据库操作Service实现
* @createDate 2024-06-26 08:58:29
*/
@Service
public class MobileServiceImpl extends ServiceImpl<MobileMapper, Mobile>
    implements MobileService{

    //注入MobileMapper接口代理对象
    @Autowired
    private MobileMapper mobileMapper;
    @Autowired
    private RedisTemplate redisTemplate;
    @Override
    public ResponseBean<String> login(Mobile mobile) {
        ResponseBean<String> responseBean=new ResponseBean<>();
        //创建对象封装where条件
        QueryWrapper<Mobile> wrapper=new QueryWrapper<>();
        wrapper.eq("telephone",mobile.getTelephone());
        //通过用户名查询数据库 where telephone=?
        Mobile result = mobileMapper.selectOne(wrapper);
        //判断用户名（手机号）是否存在
        if(result==null){
            //用户名不合法
            responseBean.setCode(801);
            responseBean.setMsg("输入手机号错误.....");
            return responseBean;
        }
        //判断密码是否合法
        if(!result.getPassword().equals(mobile.getPassword())){
            //密码不合法
            responseBean.setCode(802);
            responseBean.setMsg("输入密码错误......");
            return responseBean;
        }
        //完成正常响应,需要响应登录验证后的token
        responseBean.setCode(200);
        String token="";
        responseBean.setData(token);
        //创建ObjectMapper对象
        ObjectMapper objectMapper=new ObjectMapper();
        String jsonString = null;
        try {
            jsonString = objectMapper.writeValueAsString(result);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        System.out.println("jsonString="+jsonString);
        //同时将token数据保存到redis数据库，设置保存周期
        token = JwtTool.createToken(jsonString);
        System.out.println("token="+token);
        //将token数据封装到responseBean
        responseBean.setData(token);
        return responseBean;
    }

    @Override
    public ResponseBean<String> checkPhone(String telephone) {
        ResponseBean<String> result=new ResponseBean<>();
        //创建对象封装where条件
        QueryWrapper<Mobile> wrapper=new QueryWrapper<>();
        wrapper.eq("telephone",telephone);
        //根据手机号码查询数据
        Long count = mobileMapper.selectCount(wrapper);
        //判断手机号码是否存在
        if(count>0){
            //该号码已经使用，需要错误提示
            result.setCode(801);
            result.setMsg(telephone+"已经被注册.....");
        }else{
            //该号码可以用
            result.setCode(200);
            //产生随机验证码
            String code = Coder.checkCode();
            //将code验证码保存到redis数据库
            redisTemplate.boundValueOps(code).set(code,2, TimeUnit.MINUTES);
            result.setData(code);//验证码
        }


        return result;
    }

    @Override
    public ResponseBean<String> checkNumber(String code) {
        ResponseBean<String> responseBean=new ResponseBean<>();
        Object result = redisTemplate.boundValueOps(code).get();
        if(result==null){
            //验证码不存在
            responseBean.setCode(801);
            responseBean.setMsg("验证码过期或者输入错误....");
            return responseBean;
        }
        //验证码正确
        responseBean.setCode(200);
        responseBean.setMsg("验证通过....");
        return responseBean;
    }

    @Override
    public ResponseBean<Integer> register(Mobile mobile) {
        ResponseBean<Integer> responseBean=new ResponseBean<>();
        int row = mobileMapper.insert(mobile);
        if(row>0){
            responseBean.setCode(200);
        }else{
            responseBean.setCode(801);
        }
        return responseBean;
    }
}




