package com.dr.service;

import com.dr.domain.ResponseBean;
import com.dr.domain.Transrecord;
import com.baomidou.mybatisplus.extension.service.IService;
import com.dr.domain.TransrecordSub;

import java.util.List;
import java.util.Map;

/**
* @author 您好
* @description 针对表【transrecord】的数据库操作Service
* @createDate 2024-06-26 08:58:29
*/
public interface TransrecordService extends IService<Transrecord> {

    /*查询某个账号对应的交易记录*/
    public ResponseBean<List<TransrecordSub>> searchRecordList(Integer accountId);
//    实现转账业务
    public ResponseBean<Integer> transMoney(Map<String,Map<String,Object>> params);
 }
