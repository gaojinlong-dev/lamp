package com.dr.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.dr.domain.*;
import com.dr.mapper.AccountMapper;
import com.dr.mapper.PersoninfoMapper;
import com.dr.service.TransrecordService;
import com.dr.mapper.TransrecordMapper;
import com.fasterxml.jackson.databind.util.BeanUtil;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
* @author 您好
* @description 针对表【transrecord】的数据库操作Service实现
* @createDate 2024-06-26 08:58:29
*/
@Service
public class TransrecordServiceImpl extends ServiceImpl<TransrecordMapper, Transrecord>
    implements TransrecordService{
    @Autowired
    private AccountMapper accountMapper;
    @Autowired
    private TransrecordMapper transrecordMapper;
    @Autowired
    private PersoninfoMapper personinfoMapper;


    @Override
    public ResponseBean<List<TransrecordSub>> searchRecordList(Integer accountid) {
        ResponseBean<List<TransrecordSub>> result=new ResponseBean<>();
        //查询交易记录信息
        QueryWrapper<Transrecord> wrapper=new QueryWrapper<>();
        wrapper.eq("accountid",accountid);
        List<Transrecord> transrecords = transrecordMapper.selectList(wrapper);


        //创建交易记录子类对象的集合
        List<TransrecordSub> transrecordSubs=new ArrayList<>();
        //遍历transrecords集合
        for(Transrecord transrecord:transrecords){
            //创建TransrecordSub子类对象
            TransrecordSub transrecordSub=new TransrecordSub();
            //进行属性的拷贝
            BeanUtils.copyProperties(transrecord,transrecordSub);
            //transrecordSub的accountSubA赋值
            Account accountA = accountMapper.selectById(transrecord.getAccountid());
            AccountSub accountSubA=new AccountSub();
            BeanUtils.copyProperties(accountA,accountSubA); //属性拷贝
            //对象的person属性赋值
            Personinfo personinfoA = personinfoMapper.selectById(accountA.getPersonid());
            accountSubA.setPersonInfo(personinfoA);
            transrecordSub.setAccountSubA(accountSubA);



            //transrecordSub的accountSubB赋值
            Account accountB = accountMapper.selectById(transrecord.getOtherid());
            AccountSub accountSubB=new AccountSub();
            BeanUtils.copyProperties(accountB,accountSubB);

            //对象accountSubB的personinfo属性赋值
            Personinfo personinfoB = personinfoMapper.selectById(accountB.getPersonid());
            accountSubB.setPersonInfo(personinfoB);
            transrecordSub.setAccountSubB(accountSubB);

            transrecordSubs.add(transrecordSub);
        }

        result.setCode(200);
        result.setData(transrecordSubs);
        return result;
    }


    @Transactional
    @Override
    public ResponseBean<Integer> transMoney(Map<String, Map<String, Object>> params) {
        ResponseBean<Integer> result=new ResponseBean<>();
//        解析params
        Map<String,Object> zhuanchu= params.get("zhuanchu");
        String zhuanchuId = zhuanchu.get("id").toString();
        String money = zhuanchu.get("balance").toString();
        Object password = zhuanchu.get("password");

        Map<String,Object>zhuanru=params.get("zhuanru");
        String zhuanruId = zhuanru.get("id").toString();

        Account account=accountMapper.selectById((Serializable) zhuanchuId);
        if(!(account!=null&&(account.getPassword().equals(password)))){
            result.setCode(801);
            result.setMsg("输入转账密码错误");
            return result;
        }

        //修改转出和转入账号对应的余额
        //更新转出账号余额
        Account chu=new Account();
        chu.setId(Integer.valueOf(zhuanchuId));
        //将转出金额money封装为高精度类型
        BigDecimal num=new BigDecimal(Integer.valueOf(money));
        //账户余额减去转出的金额
        BigDecimal subtract = account.getBalance().subtract(num);
        chu.setBalance(subtract);
        accountMapper.updateById(chu);


        //给转入账号id查询余额
        Account ru = accountMapper.selectById((Serializable) zhuanruId);
        //修改ru对象余额
        BigDecimal add = ru.getBalance().add(num);
        ru.setBalance(add);
        accountMapper.updateById(ru);

        //产生转出和传入的账号对应的交易记录
        //产生转出账号交易记录
        Transrecord chuRecord=new Transrecord();
        chuRecord.setAccountid(Integer.valueOf(zhuanchuId) );
        chuRecord.setOtherid(Integer.valueOf(zhuanruId));
        chuRecord.setMoney(new BigDecimal(Integer.valueOf(money)));
        chuRecord.setTransdate(LocalDateTime.now().toString());
        chuRecord.setTranstypeid(2);
        transrecordMapper.insert(chuRecord);
        //产生转入账号交易记录
        Transrecord ruRecord=new Transrecord();
        ruRecord.setAccountid(Integer.valueOf(zhuanruId));
        ruRecord.setMoney(new BigDecimal(Integer.valueOf(money)));
        ruRecord.setOtherid(Integer.valueOf(zhuanchuId));
        ruRecord.setTranstypeid(2);
        ruRecord.setTransdate(LocalDateTime.now().toString());
        transrecordMapper.insert(ruRecord);
        result.setCode(200);
        return result;
    }
}




