package com.dr.controller;

import com.dr.domain.RecipientSub;
import com.dr.domain.ResponseBean;
import com.dr.service.RecipientService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/recipient")
public class RecipientController {
    @Autowired
    private RecipientService recipientService;

    /*处理加载收款人列表请求*/
    @GetMapping("/findAll")
    public ResponseBean<List<RecipientSub>> find(Integer telId){
        return recipientService.queryRecipientList(telId);
    }
    /*处理添加收款人请求*/
    @PostMapping("/addRecipient")
    public ResponseBean<Integer> save(@RequestBody Map<String,Object> map){
        return recipientService.saveRecipient(map);
    }
    /*实现收款人更新*/
    @PostMapping("/updateRecipient")
    public ResponseBean<Integer> update(@RequestBody Map<String,Object> map){
        return recipientService.updateRecipient(map);
    }
//  实现收款人删除
    @PostMapping("/removeRecipient")
    public ResponseBean<Integer> removeRecipient(Integer recipientId){
         return recipientService.removeRecipient(recipientId);
    }
}
