package com.dr.controller;

import com.dr.domain.Account;
import com.dr.domain.ResponseBean;
import com.dr.service.AccountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/account")
public class AccountController {

    //注入service
    @Autowired
    private AccountService accountService;

    /*处理根据手机号码加载账户列表*/
    @GetMapping("/findRelatedAccountByTel")
    public ResponseBean<List<Account>> findAccountByTel(String telephone){
        return accountService.findRelatedAccountByTel(telephone);
    }
    /*处理根据手机号码未绑定账户列表请求*/
    @GetMapping("/findUnRelatedAccountByTel")
    public ResponseBean<List<Account>> findUnAccountByTel(String telephone){
        return accountService.findUnRelatedAccountByTel(telephone);
    }
    /*处理加载根据账户id查询账户信息请求*/
    @GetMapping("/searchByAccountId")
    public ResponseBean<Account> searchByAccountId(Integer accountId){
        Account account = accountService.getById(accountId);
        ResponseBean<Account> result=new ResponseBean<>();
        result.setCode(200);
        result.setData(account);
        return result;
    }
}
