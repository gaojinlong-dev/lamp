package com.dr.controller;

import com.dr.domain.Mobile;
import com.dr.domain.ResponseBean;
import com.dr.service.MobileService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/mobile")
public class MobileController {
    //注入service
    @Autowired
    private MobileService mobileService;

    /*处理用户登录的请求*/
    @PostMapping("/login")
    public ResponseBean<String> login(Mobile mobile){
        return mobileService.login(mobile);
    }

    /*处理要做手机号码是否可用请求*/
    @GetMapping("/sendCode")
    public ResponseBean<String> check(String telephone){
        return mobileService.checkPhone(telephone);
    }

    /*处理验证验证码是否正确的请求*/
    @PostMapping("/checkCode")
    public ResponseBean<String> checkCode(String code){
        return mobileService.checkNumber(code);
    }
    /*处理用户注册的请求*/
    @PostMapping("/regMobile")
    public ResponseBean<Integer> register(Mobile mobile){
        return mobileService.register(mobile);
    }

}
