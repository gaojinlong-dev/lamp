package com.dr.controller;

import com.dr.domain.ResponseBean;
import com.dr.domain.TransrecordSub;
import com.dr.service.TransrecordService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/transrecord")
public class TransrecordController {

    @Autowired
    private TransrecordService transrecordService;

    /*处理加载账户交易记录请求*/
    @GetMapping("/findTransRecord")
    public ResponseBean<List<TransrecordSub>> findTrans(Integer accountId){
        return transrecordService.searchRecordList(accountId);
    }
}
