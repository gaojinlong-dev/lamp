package com.dr.controller;

import com.dr.domain.ResponseBean;
import com.dr.service.TransrecordService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
@RequestMapping("/transfer")
public class TransferController {

    @Autowired
    private TransrecordService transrecordService;
    /*处理转账请求*/
    @PostMapping("/trans")
    public ResponseBean<Integer> trans(@RequestBody Map<String, Map<String,Object>> params){
        return transrecordService.transMoney(params);
    }
}


