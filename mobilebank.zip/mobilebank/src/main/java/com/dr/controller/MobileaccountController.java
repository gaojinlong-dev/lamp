package com.dr.controller;

import com.dr.domain.Mobileaccount;
import com.dr.domain.ResponseBean;
import com.dr.service.MobileaccountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/mobileaccount")
public class MobileaccountController {
    @Autowired
    private MobileaccountService mobileaccountService;
    // 添加手机和账户的关联信息
    @PostMapping("/addRelatedAccount")
    public ResponseBean<Integer> addRelatedAccount(Mobileaccount telId){
        return mobileaccountService.addRelatedAccount(telId);
    }
}

