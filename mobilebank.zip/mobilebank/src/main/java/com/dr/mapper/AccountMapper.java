package com.dr.mapper;

import com.dr.domain.Account;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
* @author 您好
* @description 针对表【account】的数据库操作Mapper
* @createDate 2024-06-26 08:58:29
* @Entity com.dr.domain.Account
*/
@Mapper
public interface AccountMapper extends BaseMapper<Account> {

    /*根据手机号码查询该手机号码绑定的用户的账户列表*/
    public List<Account> selectAccountListMapper(String phone);

    /*根据手机号码查询该手机号码没有绑定的用户的账户列表*/
    public List<Account> selectUnAccountListMapper(String phone);
}




