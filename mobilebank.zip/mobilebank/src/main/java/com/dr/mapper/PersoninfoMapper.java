package com.dr.mapper;

import com.dr.domain.Personinfo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
* @author 您好
* @description 针对表【personinfo】的数据库操作Mapper
* @createDate 2024-06-26 08:58:29
* @Entity com.dr.domain.Personinfo
*/
@Mapper
public interface PersoninfoMapper extends BaseMapper<Personinfo> {

}




