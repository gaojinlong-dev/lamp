package com.dr.mapper;

import com.dr.domain.Mobile;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
* @author 您好
* @description 针对表【mobile】的数据库操作Mapper
* @createDate 2024-06-26 08:58:29
* @Entity com.dr.domain.Mobile
*/
//通过继承BaseMapper获得对数据库表进行CRUD的方法，自己可以扩展
@Mapper
public interface MobileMapper extends BaseMapper<Mobile> {

}




