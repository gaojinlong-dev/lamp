package com.dr.domain;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import lombok.Data;

/**
 * 
 * @TableName mobile
 */
//指定该实体类映射的数据库表
@TableName(value ="mobile")
@Data
public class Mobile implements Serializable {
    /**
     * 指定该属性映射的是数据库主键
     */
    @TableId(type = IdType.AUTO)
    private Integer id;

    /**
     * 
     */
    private String telephone;

    /**
     * 
     */
    private String password;
    //该属性和数据库表中的列不存在映射关系
    @TableField(exist = false)
    private static final long serialVersionUID = 1L;


}