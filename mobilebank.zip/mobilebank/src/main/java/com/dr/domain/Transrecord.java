package com.dr.domain;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

/**
 * 
 * @TableName transrecord
 */
@TableName(value ="transrecord")
@Data
public class Transrecord implements Serializable {
    /**
     * 
     */
    @TableId(type = IdType.AUTO)
    private Integer id;

    /**
     * 
     */
    private Integer accountid;

    /**
     * 
     */
    private Integer otherid;

    /**
     * 
     */
    private BigDecimal money;

    /**
     * 
     */
    @JsonProperty("transDate")
    private String transdate;

    /**
     * 
     */
    @JsonProperty("transtypeId")
    private Integer transtypeid;

    @TableField(exist = false)
    private static final long serialVersionUID = 1L;

    @Override
    public boolean equals(Object that) {
        if (this == that) {
            return true;
        }
        if (that == null) {
            return false;
        }
        if (getClass() != that.getClass()) {
            return false;
        }
        Transrecord other = (Transrecord) that;
        return (this.getId() == null ? other.getId() == null : this.getId().equals(other.getId()))
            && (this.getAccountid() == null ? other.getAccountid() == null : this.getAccountid().equals(other.getAccountid()))
            && (this.getOtherid() == null ? other.getOtherid() == null : this.getOtherid().equals(other.getOtherid()))
            && (this.getMoney() == null ? other.getMoney() == null : this.getMoney().equals(other.getMoney()))
            && (this.getTransdate() == null ? other.getTransdate() == null : this.getTransdate().equals(other.getTransdate()))
            && (this.getTranstypeid() == null ? other.getTranstypeid() == null : this.getTranstypeid().equals(other.getTranstypeid()));
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getId() == null) ? 0 : getId().hashCode());
        result = prime * result + ((getAccountid() == null) ? 0 : getAccountid().hashCode());
        result = prime * result + ((getOtherid() == null) ? 0 : getOtherid().hashCode());
        result = prime * result + ((getMoney() == null) ? 0 : getMoney().hashCode());
        result = prime * result + ((getTransdate() == null) ? 0 : getTransdate().hashCode());
        result = prime * result + ((getTranstypeid() == null) ? 0 : getTranstypeid().hashCode());
        return result;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", id=").append(id);
        sb.append(", accountid=").append(accountid);
        sb.append(", otherid=").append(otherid);
        sb.append(", money=").append(money);
        sb.append(", transdate=").append(transdate);
        sb.append(", transtypeid=").append(transtypeid);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }
}