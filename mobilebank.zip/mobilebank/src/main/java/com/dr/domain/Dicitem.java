package com.dr.domain;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import lombok.Data;

/**
 * 
 * @TableName dicitem
 */
@TableName(value ="dicitem")
@Data
public class Dicitem implements Serializable {
    /**
     * 
     */
    @TableId(type = IdType.AUTO)
    private Integer dicitemid;

    /**
     * 
     */
    private Integer dictypecode;

    /**
     * 
     */
    private Integer dicitemcode;

    /**
     * 
     */
    private String dicitemname;

    @TableField(exist = false)
    private static final long serialVersionUID = 1L;

    @Override
    public boolean equals(Object that) {
        if (this == that) {
            return true;
        }
        if (that == null) {
            return false;
        }
        if (getClass() != that.getClass()) {
            return false;
        }
        Dicitem other = (Dicitem) that;
        return (this.getDicitemid() == null ? other.getDicitemid() == null : this.getDicitemid().equals(other.getDicitemid()))
            && (this.getDictypecode() == null ? other.getDictypecode() == null : this.getDictypecode().equals(other.getDictypecode()))
            && (this.getDicitemcode() == null ? other.getDicitemcode() == null : this.getDicitemcode().equals(other.getDicitemcode()))
            && (this.getDicitemname() == null ? other.getDicitemname() == null : this.getDicitemname().equals(other.getDicitemname()));
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getDicitemid() == null) ? 0 : getDicitemid().hashCode());
        result = prime * result + ((getDictypecode() == null) ? 0 : getDictypecode().hashCode());
        result = prime * result + ((getDicitemcode() == null) ? 0 : getDicitemcode().hashCode());
        result = prime * result + ((getDicitemname() == null) ? 0 : getDicitemname().hashCode());
        return result;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", dicitemid=").append(dicitemid);
        sb.append(", dictypecode=").append(dictypecode);
        sb.append(", dicitemcode=").append(dicitemcode);
        sb.append(", dicitemname=").append(dicitemname);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }
}