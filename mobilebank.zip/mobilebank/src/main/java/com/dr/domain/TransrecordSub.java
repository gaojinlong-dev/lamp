package com.dr.domain;

import lombok.Data;

@Data
public class TransrecordSub extends Transrecord{
    //扩展属性表示交易双方
    private AccountSub accountSubA;  //acountid
    private AccountSub accountSubB; //otherid
}
