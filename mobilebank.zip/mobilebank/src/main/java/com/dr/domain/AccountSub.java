package com.dr.domain;

import lombok.Data;

@Data
public class AccountSub extends Account{

    //通过继承拥有accountName属性
    //扩展属性personinfo属性
    private Personinfo personInfo;
}
