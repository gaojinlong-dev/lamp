package com.dr.domain;

import lombok.Data;

@Data
public class RecipientSub extends Recipient{

    private AccountSub accountSub;
}
