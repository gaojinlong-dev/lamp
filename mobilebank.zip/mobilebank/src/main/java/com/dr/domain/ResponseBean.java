package com.dr.domain;

import lombok.Data;

/*封装后台响应到前端的数据模型*/
@Data
public class ResponseBean<T> {
    private Integer code; //状态码
    private String msg; //提示消息
    private T data; //响应数据
}
