package com.dr;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
//扫描mapper接口所在的包，产生代理对象
@MapperScan(basePackages = "com.dr.mapper")
public class MobilebankApplication {

    public static void main(String[] args) {
        SpringApplication.run(MobilebankApplication.class, args);
        System.out.println("启动成功啦~");
    }

}
